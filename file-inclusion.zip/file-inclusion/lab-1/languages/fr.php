<?php
echo "Bienvenue, ceci est la page en français.";

