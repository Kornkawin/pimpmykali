<?php
// Middleware for security filters

function validateInput($input) {
    // filter out ../
    $input = str_replace("../", "", $input);

    // filter out ../ recursively
    while (strpos($input, "../") !== false) {
        $input = str_replace("../", "", $input);
    }

    // block characters
    $charsToRemove = [';', '|', '&', '$'];
    foreach ($charsToRemove as $char) {
        $input = str_replace($char, "", $input);
    }

    return $input;
}
