<?php
include 'filter.php';

if (isset($_GET['lang'])) {
    $lang = validateInput($_GET['lang']);
    $path = "languages/" . $lang . ".php";
    include($path);
} else {
    echo "Please select a language.";
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Language Selection</title>
</head>
<body>
    <h2>Select a Language</h2>
    <ul>
        <li><a href="?lang=en">English</a></li>
        <li><a href="?lang=fr">French</a></li>
    </ul>
</body>
</html>
<?php
echo 'debug: ' . $path;
?>
