const express = require("express");
const mongoose = require("mongoose");
const axios = require("axios");
const cookieParser = require("cookie-parser");
const swaggerUi = require("swagger-ui-express");
const YAML = require("yamljs");
const swaggerDocument = YAML.load("./swagger.yaml");
const bcrypt = require("bcrypt");
const saltRounds = 10;
const { exec } = require("child_process");

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());

mongoose
  .connect("mongodb://mongo:27017/nosqli-demo", { useNewUrlParser: true })
  .then(() => console.log("MongoDB Connected"))
  .catch((err) => console.log(err));

const User = require("./models/User");
const Pun = require("./models/Pun");
const Recipe = require("./models/Recipe");

// Swagger UI endpoint
app.use("/", swaggerUi.serve);
app.get("/", swaggerUi.setup(swaggerDocument));

// AUTH endpoints

// register
app.post("/v1/auth/register", (req, res) => {
  const { username, password } = req.body;

  // Check if username or password are missing
  if (!username || !password) {
    return res
      .status(400)
      .json({ message: "Username and password are required" });
  }

  // Check if username already exists
  User.findOne({ username }, (err, existingUser) => {
    if (err) {
      console.log(err);
      return res.status(500).json({ message: "Error checking username" });
    }

    if (existingUser) {
      return res.status(409).json({ message: "Username already exists" });
    }

    // Hash password
    bcrypt.hash(password, saltRounds, (err, hash) => {
      if (err) {
        console.log(err);
        return res.status(500).json({ message: "Error hashing password" });
      }

      const length = 6;
      let result = "";
      const characters =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
      const charactersLength = characters.length;
      for (let i = 0; i < length; i++) {
        result += characters.charAt(
          Math.floor(Math.random() * charactersLength)
        );
      }

      let newUser = new User({ ...req.body });
      newUser.password = hash;
      const sessionId = Buffer.from(username + result).toString("base64");
      newUser.session = sessionId;
      newUser
        .save()
        .then((user) => {
          res.json({
            message: "Registration successful",
            sessionId: sessionId,
          });
        })
        .catch((err) => {
          console.log(err);
          res.status(500).json({ message: "Error saving user" });
        });
    });
  });
});

// login
app.post("/v1/auth/login", async (req, res) => {
  const { username, password } = req.body;
  const user = await User.findOne({ username });

  if (!user) {
    return res.status(401).json({ message: "Invalid username or password" });
  }

  // Compare password
  bcrypt.compare(password, user.password, (err, result) => {
    if (err) {
      console.log(err);
      return res.status(500).json({ message: "Error comparing password" });
    }

    if (!result) {
      return res.status(401).json({ message: "Invalid username or password" });
    }

    const length = 6;
    let sessionResult = "";
    const characters =
      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    const charactersLength = characters.length;
    for (let i = 0; i < length; i++) {
      sessionResult += characters.charAt(
        Math.floor(Math.random() * charactersLength)
      );
    }
    const sessionId = Buffer.from(username + sessionResult).toString("base64");
    user.session = sessionId;
    user
      .save()
      .then(() => {
        res.json({ message: "Login successful", sessionId: sessionId });
      })
      .catch((err) => {
        console.log(err);
        res.status(500).json({ message: "Error saving session ID" });
      });
  });
});

// middleware function to check session ID cookie
const checkSessionId = async (req, res, next) => {
  const { sessionId } = req.body;
  if (!sessionId) {
    // Redirect to login page if session ID cookie is missing
    res.status(401).json({ message: "Unauthorized" });
  } else {
    // Check if the session ID exists in the database
    User.findOne({ session: sessionId }, (err, user) => {
      if (err) {
        console.log(err);
        res.status(500).json({ message: "Error checking session ID" });
      } else if (!user) {
        // Redirect to login page if session ID is invalid
        res.status(401).json({ message: "Unauthorized" });
      } else {
        // Set the user object in the request for use in other middleware functions and routes
        req.user = user;
        next();
      }
    });
  }
};

// check the session token is valid
app.post("/v1/auth/check", checkSessionId, (req, res) => {
  // Only accessible if the user has a valid session ID cookie
  res.json({ message: "Session valid", username: `${req.user.username}` });
});

// RECIPE endpoints

// add new recipe
app.post("/v1/recipes", checkSessionId, async (req, res) => {
  try {
    const { name, ingredients, method, isPrivate } = req.body;
    const username = req.user.username;

    const recipe = new Recipe({
      name,
      ingredients,
      method,
      rating: 0,
      chef: username,
      isPrivate,
    });

    await recipe.save();
    res.status(201).json({ message: "Recipe created successfully", recipe });
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server Error");
  }
});

// update a recipe
app.put("/v1/recipes/:id", async (req, res) => {
  const recipeId = req.params.id;
  const recipe = await Recipe.findById(recipeId);

  if (!recipe) {
    return res.status(404).json({ message: "Recipe not found" });
  }

  const { name, ingredients, method, rating, isPrivate, original } = req.body;
  const userSessionId = req.body.sessionId;
  const user = await User.findOne({ session: userSessionId });

  if (!user) {
    return res.status(401).json({ message: "Unauthorized" });
  }

  if (recipe.chef !== user.username && !user.isAdmin) {
    return res.status(401).json({ message: "Unauthorized" });
  }

  recipe.name = name || recipe.name;
  recipe.ingredients = ingredients || recipe.ingredients;
  recipe.method = method || recipe.method;
  recipe.rating = rating || recipe.rating;
  recipe.isPrivate = isPrivate || recipe.isPrivate;
  recipe.original = original || recipe.original;

  await recipe.save();

  res.json({ message: "Recipe updated successfully" });
});

// search for a recipe
app.get("/v1/recipes", async (req, res) => {
  try {
    const query = req.query.q;
    const regex = new RegExp(query, "i");
    const recipes = await Recipe.find({
      $or: [{ name: regex }, { chef: regex }],
    });
    res.json(recipes);
  } catch (err) {
    console.error(err);
    res.status(500).send("Error searching recipes");
  }
});

// get recipe by id
app.get("/v1/recipes/:id", async (req, res) => {
  try {
    const recipe = await Recipe.findById(req.params.id);

    if (!recipe) {
      return res.status(404).json({ message: "Recipe not found" });
    }

    let originalRecipe = null;
    if (recipe.original) {
      try {
        const response = await axios.get(recipe.original);
        originalRecipe = response.data;
      } catch (err) {
        console.error(err);
        originalRecipe = null;
      }
    }

    res.json({ ...recipe.toObject(), originalRecipe });
  } catch (err) {
    console.error(err);
    res.status(500).send("Error retrieving recipe");
  }
});

// DATA endpoints

// get a random title
app.get("/v1/data/title", (req, res) => {
  Pun.aggregate([{ $sample: { size: 1 } }]).exec((err, result) => {
    if (err) {
      console.log(err);
      res.status(500).json({ message: "Error retrieving pun" });
    } else {
      const pun = result[0].pun;
      res.json({ title: pun });
    }
  });
});

// list all the titles
app.get("/v1/data/titles", (req, res) => {
  Pun.find()
    .then((puns) => {
      res.json(puns);
    })
    .catch((error) => {
      console.log(error);
      res.status(500).json({ message: "Error retrieving puns" });
    });
});

// list all the users
// app.get("/v1/data/admin/users", (req, res) => {
//   User.find()
//     .then((users) => {
//       res.json(users);
//     })
//     .catch((error) => {
//       console.log(error);
//       res.status(500).json({ message: "Error retrieving users" });
//     });
// });

// ADMIN endpoints

// list all the recipes
app.get("/v1/data/admin/recipes", (req, res) => {
  const sessionId = req.body.sessionId;

  // check if session ID exists
  if (!sessionId) {
    return res.status(401).json({ message: "Unauthorized" });
  }

  // find user by session ID
  User.findOne({ session: sessionId }, (err, user) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ message: "Error retrieving user" });
    }

    // check if user exists and has admin userlevel
    if (!user || user.userlevel !== "admin") {
      return res.status(401).json({ message: "Unauthorized" });
    }

    // retrieve all recipes
    Recipe.find()
      .then((recipes) => {
        res.json(recipes);
      })
      .catch((error) => {
        console.log(error);
        res.status(500).json({ message: "Error retrieving recipes" });
      });
  });
});

// INTERNAL endpoints

// list all the uesrs
app.get("/v1/data/internal/users", (req, res) => {
  const ip = req.ip;
  // Check if the request is coming from the server's IP address
  if (ip === "127.0.0.1" || ip === "::1" || ip === "::ffff:127.0.0.1") {
    User.find()
      .then((users) => {
        res.json(users);
      })
      .catch((error) => {
        console.log(error);
        res.status(500).json({ message: "Error retrieving users" });
      });
  } else {
    // Return a 401 Unauthorized response if the request is coming from a different IP address
    res.status(401).json({
      message: "Sorry, for security this endpoint is only accessible locally",
    });
  }
});

app.get("/v1/data/internal/uptime", (req, res) => {
  const ip = req.ip;
  // Check if the request is coming from the server's IP address
  if (ip === "127.0.0.1" || ip === "::1" || ip === "::ffff:127.0.0.1") {
    // Execute a bash command to check the server's uptime
    exec("uptime", (error, stdout, stderr) => {
      if (error) {
        console.error(`exec error: ${error}`);
        return res
          .status(500)
          .json({ message: "Error checking server uptime" });
      }
      res.send(stdout);
    });
  } else {
    // Return a 401 Unauthorized response if the request is coming from a different IP address
    res.status(401).json({
      message: "Sorry, for security this endpoint is only accessible locally",
    });
  }
});

// RESET THE APP
app.get("/controls/reset", (req, res) => {
  Promise.all([User.deleteMany({}), Recipe.deleteMany({}), Pun.deleteMany({})])
    .then((results) => {
      const deletedUsers = results[0].deletedCount;
      const deletedRecipes = results[1].deletedCount;
      const deletedPuns = results[2].deletedCount;
      console.log(`${deletedUsers} users deleted`);
      console.log(`${deletedRecipes} recipes deleted`);
      console.log(`${deletedPuns} puns deleted`);

      // add the puns
      const puns = [
        "I walked right pasta and didn’t even notice!",
        "Life is full of pasta-bilities.",
        "Can you pasta sauce please?",
        "This too shall pasta.",
        "Pasta la vista, baby.",
      ];
      puns.forEach((pun) => {
        const newPun = new Pun({ pun });
        newPun.save();
      });

      // add the administrator
      const newUser = new User({
        username: "admin",
        password: "admin",
        userlevel: "admin",
      });
      newUser.session = "admin";
      newUser.save();

      // add some recipes
      const recipes = [
        {
          name: "Spaghetti with Meat Sauce",
          ingredients: {
            spaghetti: "8 ounces",
            ground_beef: "1 pound",
            onion: "1 large, chopped",
            garlic: "3 cloves, minced",
            canned_tomatoes: "1 can (28 ounces), crushed",
            tomato_paste: "1 can (6 ounces)",
            dried_basil: "1 tablespoon",
            dried_oregano: "1 tablespoon",
            salt: "1 teaspoon",
            black_pepper: "1/4 teaspoon",
            olive_oil: "2 tablespoons",
            parmesan_cheese: "1/4 cup, grated",
          },
          method: {
            step1: "Cook spaghetti according to package directions.",
            step2:
              "In a large skillet, cook beef, onion and garlic over medium heat until meat is no longer pink; drain.",
            step3:
              "Stir in the tomatoes, tomato paste, basil, oregano, salt and pepper. Bring to a boil. Reduce heat; simmer, uncovered, for 30 minutes, stirring occasionally.",
            step4:
              "Drain spaghetti; toss with meat sauce. Drizzle with olive oil; sprinkle with cheese.",
          },
          rating: 4.5,
          chef: "admin",
          isPrivate: true,
        },
        {
          name: "Fettuccine Alfredo",
          ingredients: {
            fettuccine: "8 ounces",
            heavy_cream: "1 cup",
            butter: "1/2 cup",
            garlic: "3 cloves, minced",
            parmesan_cheese: "1/2 cup, grated",
            salt: "1/2 teaspoon",
            black_pepper: "1/4 teaspoon",
          },
          method: {
            step1: "Cook fettuccine according to package directions.",
            step2:
              "In a large skillet, heat cream and butter over low heat until butter is melted.",
            step3:
              "Stir in garlic, parmesan cheese, salt and black pepper. Cook and stir until cheese is melted and sauce is heated through.",
            step4: "Drain fettuccine; toss with sauce.",
          },
          rating: 4.2,
          chef: "alex",
          isPrivate: false,
        },
      ];

      recipes.forEach((recipe) => {
        const newRecipe = new Recipe(recipe);
        newRecipe.save();
      });

      res.json({ message: "App data reset" });
    })
    .catch((error) => {
      console.log(error);
      res.status(500).send("Error clearing data");
    });
});

// show test data
app.get("/controls/sampleData", (req, res) => {
  const infoString = `
  <!DOCTYPE html>
<html>
<head>
	<title>Sample API Requests</title>
</head>
<body>
	<h1>API Requests</h1>
	<ul>
		<li><code>POST /v1/auth/register {"username":"test","password":"test"}</code></li>
		<li><code>POST /v1/auth/login {"username":"test","password":"test"}</code></li>
		<li><code>POST /v1/auth/check {"sessionId":"test"}</code></li>
		<li><code>GET /v1/recipes?q=pasta</code></li>
		<li><code>GET /v1/recipes/:id</code></li>
		<li>
			<code>POST /v1/recipes</code>
			<pre>
{
  "sessionId": "sessionId",
  "name": "Pasta Carbonara",
  "original": "undefined",
  "ingredients": {
    "Pasta": "Spaghetti",
    "Bacon": "200g",
    "Egg": "2",
    "Parmesan Cheese": "50g",
    "Black Pepper": "To taste",
    "Salt": "To taste"
  },
  "method": {
    "Step 1": "Cook spaghetti in salted boiling water until al dente",
    "Step 2": "Fry bacon until crispy and remove from heat",
    "Step 3": "In a bowl, whisk together eggs, grated Parmesan cheese, and black pepper",
    "Step 4": "Drain pasta and reserve 1/2 cup of pasta water",
    "Step 5": "Add cooked spaghetti to the bacon and toss until coated with bacon fat",
    "Step 6": "Add reserved pasta water to the egg mixture and whisk to combine",
    "Step 7": "Pour the egg mixture over the spaghetti and bacon and toss until coated",
    "Step 8": "Serve immediately, garnished with additional grated Parmesan cheese and black pepper"
  },
  "rating": 4,
  "isPrivate": true
}
            </pre>
		</li>
		<li>
			<code>PUT /v1/recipes/64130bdf32e0b603ecf14544</code>
			<pre>
{
  "sessionId": "sessionId",
  "name": "Pasta Carbonara",
  "original": "link-to-original-recipe",
  "ingredients": {
    "Pasta": "Spaghetti",
    "Bacon": "200g",
    "Egg": "2",
    "Parmesan Cheese": "50g",
    "Black Pepper": "To taste",
    "Salt": "To taste"
  },
  "method": {
    "Step 1": "Cook spaghetti in salted boiling water until al dente",
    "Step 2": "Fry bacon until crispy and remove from heat",
    "Step 3": "In a bowl, whisk together eggs, grated Parmesan cheese, and black pepper",
    "Step 4": "Drain pasta and reserve 1/2 cup of pasta water",
    "Step 5": "Add cooked spaghetti to the bacon and toss until coated with bacon fat",
    "Step 6": "Add reserved pasta water to the egg mixture and whisk to combine",
    "Step 7": "Pour the egg mixture over the spaghetti and bacon and toss until coated",
    "Step 8": "Serve immediately, garnished with additional grated Parmesan cheese and black pepper"
  },
  "rating": 4,
  "isPrivate": true
}
            </pre>
		</li>
    <li><code>GET /v1/data/title</code></li>
		<li><code>GET/v1/data/titles</code></li>
		<li><code>GET /v1/data/admin/recipes {"sessionId":"test"}</code></li>
		<li><code>/v1/data/internal/uptime</code></li>
	</ul>
  <h2>Sample Request</h2>
<pre>
POST /v1/auth/register HTTP/1.1
Host: localhost:3000
User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:91.0) Gecko/20100101 Firefox/91.0
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,/;q=0.8
Accept-Language: en-US,en;q=0.5
Accept-Encoding: gzip, deflate
Connection: close
Upgrade-Insecure-Requests: 1
Sec-Fetch-Dest: document
Sec-Fetch-Mode: navigate
Sec-Fetch-Site: none
Sec-Fetch-User: ?1
Content-Length: 48
Content-Type: application/json;charset=UTF-8

{"username":"newuser","password":"newuser"}
</pre>
</body>
</html>
  `;

  res.send(infoString);
});

const port = 3000;
app.listen(port, () => console.log("Server running..."));
