const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const RecipeSchema = new Schema({
  name: {
    type: String,
    required: true,
    default: "undefined"
  },
  ingredients: {
    type: Map,
    of: String,
    required: true
  },
  method: {
    type: Map,
    of: String,
    required: true
  },
  rating: {
    type: Number,
    required: true,
    default: 0
  },
  chef: {
    type: String,
    required: true,
    default: "undefined"
  },
  isPrivate: {
    type: Boolean,
    required: true,
    default: true
  },
  original: {
    type: String,
    required: true,
    default: "undefined"
  }
});

module.exports = Recipe = mongoose.model("recipe", RecipeSchema);
