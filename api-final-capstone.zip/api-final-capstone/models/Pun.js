const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const PunSchema = new Schema({
  pun: {
    type: String,
    required: true
  }
});

module.exports = Pun = mongoose.model('pun', PunSchema);
