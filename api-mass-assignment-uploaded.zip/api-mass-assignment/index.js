const express = require('express');
const mongoose = require('mongoose');
const app = express();

app.set('view engine', 'ejs');
app.use(express.urlencoded({ extended: false }));

mongoose
  .connect(
    'mongodb://mongo:27017/nosqli-demo',
    { useNewUrlParser: true }
  )
  .then(() => console.log('MongoDB Connected'))
  .catch(err => console.log(err));

const User = require('./models/User');

// index page
app.get('/', (req, res) => {
    User.find().then(users => res.render('index', { users }))
});

// create a new user
app.post('/register', (req, res) => {
  const newUser = new User({ ...req.body });
  newUser.save().then(user => res.redirect('/'));
});

// clear the current users
app.get('/clear', (req, res) => {
  User.deleteMany({}, function(err, result) {
    if (err) throw err;
    console.log(result.deletedCount + ' users deleted');
  });
  res.redirect('/');
});

const port = 3000;
app.listen(port, () => console.log('Server running...'));
